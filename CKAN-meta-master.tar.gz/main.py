import os
sum=0
for dirpath,dirnames,filenames in os.walk('.'):
    for i in dirnames:
        for dirpath1,dirnames,filenames in os.walk(i):
            for filename in filenames:
                os.system("sed 's/github.com/hub.fastgit.xyz/g' "+dirpath+"/"+i+"/"+filename)
                sum=sum+1
                print("sum:"+str(sum))